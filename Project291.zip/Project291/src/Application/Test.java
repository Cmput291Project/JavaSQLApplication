package Application;

/*
 * Populate the database with insert statemetns, Create it if necessary
 * Test the quries with this class
 */
public class Test {

	public Test(MedicalDB mDB) {
		
	}
}
